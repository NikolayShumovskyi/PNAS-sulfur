mkdir rho10
cp txt0009 rho10/txt
for((k=19,i=12;k<=99;k+=10,i+=2))
do
mkdir rho$i
cp txt00$k rho$i/txt
done
for((k=109,i=30;k<=359;k+=10,i+=2))
do
mkdir rho$i
cp txt0$k rho$i/txt
done
