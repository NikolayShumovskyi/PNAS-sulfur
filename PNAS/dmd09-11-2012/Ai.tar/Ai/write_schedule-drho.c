#include <stdio.h>
#include <math.h>
main()
{
  FILE *ff;
  double rho,T,drho,rhomin,dt;
  int i,n,na;
  printf("what is dro?\n");
  scanf("%lf",&drho);
  printf("what is romin?\n");
  scanf("%lf",&rhomin);
  printf("what is n?\n");
  scanf("%d",&n);
  printf("what is na?\n");
  scanf("%d",&na);
  printf("what is T\n");
  scanf("%lf",&T);
  printf("what is dt\n");
  scanf("%lf",&dt);
  ff=fopen("schedule","w");

  fprintf(ff,"N_COLL_T 1\n");
  fprintf(ff,"N_COLL_V 10\n");
  fprintf(ff,"HEAT_X_C 1\n");
  fprintf(ff,"T_0      %lf\n",T);
  fprintf(ff,"T_NEW    %lf\n",T);
  for(i=0;i<=n;i++)
    {
      rho=rhomin+i*drho;
      rho=pow(na/rho,1.0/3.0);
      fprintf(ff,"LX %lf\n",rho);
      fprintf(ff,"LY %lf\n",rho);
      fprintf(ff,"LZ %lf\n",rho);
      fprintf(ff,"TIME %lf\n",(i+1)*dt);
    }
  fclose(ff);
}
